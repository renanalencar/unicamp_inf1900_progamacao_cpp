#include <iostream>
#include <vector>

#include "Aluno.h"
#include "AlunoDisciplina.h"
#include "Disciplina.h"

int main() {
    Disciplina pp("Programação em Prolog", 11001);
    Disciplina pl("Programação em Lisp", 11002);
    Disciplina ia("Inteligência Artificial", 11201);
    Disciplina ln("Lógica Nebulosa", 11205);
    Disciplina ag("Algoritmos Genéticos", 11760);

    Aluno m(34030001);
    m.matricular(pp);
    m.matricular(ia);
    m.matricular(ln);
    std::cout << m.toString() << std::endl;

    Aluno n(34030029);
    n.matricular(pl);
    n.matricular(ln);
    n.matricular(ag);
    std::cout << n.toString() << std::endl;

    Aluno o(34030088);
    o.matricular(pp);
    o.matricular(ia);
    o.matricular(ag);
    std::cout << o.toString() << std::endl;

    std::cout << pp.toString() << std::endl;
    std::cout << pl.toString() << std::endl;
    std::cout << ia.toString() << std::endl;
    std::cout << ln.toString() << std::endl;
    std::cout << ag.toString() << std::endl;

    std::cout << "***************** Depois do trancamento ***************\n";
    o.trancar(pp);
    std::cout << o.toString() << std::endl;
    std::cout << pp.toString() << std::endl;

    return 0;
}
