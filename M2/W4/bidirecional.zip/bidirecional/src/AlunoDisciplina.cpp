#include "AlunoDisciplina.h"

AlunoDisciplina::AlunoDisciplina(class Aluno* a, class Disciplina* d) : aluno(a), disciplina(d) {}

Aluno* AlunoDisciplina::getAluno() {
	return aluno;
}

Disciplina* AlunoDisciplina::getDisciplina() {
	return disciplina;
}

void AlunoDisciplina::setAluno(Aluno* a) {
	aluno = a;
	}

void AlunoDisciplina::setDisciplina(Disciplina* d) {
	disciplina = d;
}
