#include "Aluno.h"

Aluno::Aluno(int m) : matricula(m) {}

int Aluno::getMatricula() {
	return matricula;
}

void Aluno::matricular(Disciplina& d) {
    AlunoDisciplina ad(this, &d);
    disciplinas.push_back(ad);
    d.addAluno(ad);
}

void Aluno::trancar(Disciplina& d) {
    for (int i = 0; i < disciplinas.size(); ++i) {
        if (disciplinas[i].getDisciplina() == &d) {
            d.removeAluno(disciplinas[i]);
            disciplinas.erase(disciplinas.begin() + i);
            break;
        }
    }
}

std::string Aluno::toString() {
	std::string out = "Aluno com matrícula # " + std::to_string(getMatricula()) + " está matriculado nas disciplinas:\n";
	for (int i = 0; i < disciplinas.size(); i++) {
		out += "  * " + disciplinas[i].getDisciplina()->getNome() + "\n";
	}
	return out;
}


