#include "Disciplina.h"

class AlunoDisciplina;

Disciplina::Disciplina(std::string n, int c) : nome(n), codigo(c) {}

std::string Disciplina::getNome() {
	return nome;
}

int Disciplina::getCodigo() {
	return codigo;
}

void Disciplina::addAluno(class AlunoDisciplina& a) {
	alunos.push_back(a);
}

void Disciplina::removeAluno(class AlunoDisciplina& a) {
	for (int i = 0; i < alunos.size(); ++i) {
		if (alunos[i].getAluno() == a.getAluno()) {
			alunos.erase(alunos.begin() + i);
				break;
		}
	}
}

std::string Disciplina::toString() {
	std::string out = "Alunos matriculados na disciplina código " + std::to_string(getCodigo()) + " " + getNome() + ":\n";
	for (int i = 0; i < alunos.size(); i++) {
		out += "  * " + std::to_string(alunos[i].getAluno()->getMatricula()) + "\n";
	}
	return out;
}
