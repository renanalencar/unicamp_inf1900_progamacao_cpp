#ifndef ALUNO_DISCIPLINA_H
#define ALUNO_DISCIPLINA_H

#include <iostream>
#include <vector>
#include "Aluno.h"
#include "Disciplina.h"

class AlunoDisciplina {
private:
    class Aluno* aluno;
    class Disciplina* disciplina;

public:
    AlunoDisciplina(Aluno* a, class Disciplina* d);
    Aluno* getAluno();
	Disciplina* getDisciplina();
    void setAluno(class Aluno* a); 
    void setDisciplina(class Disciplina* d);
};

#endif