#ifndef ALUNO_H
#define ALUNO_H

#include <iostream>
#include <vector>
#include "AlunoDisciplina.h"
#include "Disciplina.h"

class Aluno {
private:
    int matricula;
    std::vector<class AlunoDisciplina> disciplinas;
public:
    Aluno(int m);
    int getMatricula();
    void matricular(class Disciplina& d);
    void trancar(class Disciplina& d);
    std::string toString();
};

#endif