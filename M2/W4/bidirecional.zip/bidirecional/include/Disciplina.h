#ifndef DISCIPLINA_H
#define DISCIPLINA_H

#include <iostream>
#include <vector>
#include "AlunoDisciplina.h"

class Disciplina {
private:
    std::string nome;
    int codigo;
    std::vector<class AlunoDisciplina> alunos;

public:
    Disciplina(std::string n, int c);
    std::string getNome();
    int getCodigo();
    void addAluno(AlunoDisciplina& a); 
    void removeAluno(AlunoDisciplina& a);
    std::string toString();
};

#endif