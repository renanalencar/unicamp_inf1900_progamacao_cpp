#include "Aluno.h"
#include <iostream>
#include <vector>

Aluno::Aluno(const std::string& nome) : nome(nome) {}

const std::string& Aluno::getNome() const {
	return nome;
}

    // Método para adicionar uma disciplina ao aluno
void Aluno::adicionarDisciplina(Disciplina* disciplina) {
	disciplinas.push_back(disciplina);
}

// Método para listar as disciplinas do aluno
void Aluno::listarDisciplinas() const {
	std::cout << "Disciplinas de " << nome << ":" << std::endl;
	for (const Disciplina* disciplina : disciplinas) {
		std::cout << disciplina->getNome() << std::endl;
	}
}
