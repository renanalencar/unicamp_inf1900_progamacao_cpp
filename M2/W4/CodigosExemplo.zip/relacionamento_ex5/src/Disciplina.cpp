#include "Disciplina.h"
#include "Aluno.h"
#include <iostream>
#include <vector>

//class Aluno; // Declarando a classe Aluno antecipadamente para uso na classe Disciplina

Disciplina::Disciplina(const std::string& nome) : nome(nome) {}

const std::string& Disciplina::getNome() const {
	return nome;
}

void Disciplina::adicionarAluno(Aluno* aluno) {
	alunos.push_back(aluno);
}

void Disciplina::listarAlunos() const {
	std::cout << "Alunos na disciplina de " << nome << ":" << std::endl;
	for (const Aluno* aluno : alunos) {
		std::cout << aluno->getNome() << std::endl;
	}
}
