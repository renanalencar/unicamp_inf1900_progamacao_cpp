#include <iostream>
#include <vector>
#include "Disciplina.h"
#include "Aluno.h"

int main() {
    // Criando objetos de alunos e disciplinas
    Aluno aluno1("Alice");
    Aluno aluno2("Bob");

    Disciplina disciplina1("Matemática");
    Disciplina disciplina2("História");

    // Estabelecendo o relacionamento bidirecional
    aluno1.adicionarDisciplina(&disciplina1);
    aluno2.adicionarDisciplina(&disciplina1);

    disciplina1.adicionarAluno(&aluno1);
    disciplina1.adicionarAluno(&aluno2);

    // Listando as disciplinas dos alunos e os alunos das disciplinas
    aluno1.listarDisciplinas();
    aluno2.listarDisciplinas();

    disciplina1.listarAlunos();

    return 0;
}
