#ifndef DISCIPLINA_H
#define DISCIPLINA_H

#include <iostream>
#include <vector>

class Aluno; // Declarando a classe Aluno antecipadamente para uso na classe Disciplina

class Disciplina {
public:
    Disciplina(const std::string& nome);
    const std::string& getNome() const;
    void adicionarAluno(Aluno* aluno);
    void listarAlunos() const;
private:
    std::string nome;
    std::vector<Aluno*> alunos;
};

#endif