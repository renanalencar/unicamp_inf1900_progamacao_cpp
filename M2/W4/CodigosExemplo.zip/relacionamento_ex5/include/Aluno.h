#ifndef ALUNO_H
#define ALUNO_H

#include "Disciplina.h"

class Aluno {
public:
    Aluno(const std::string& nome);
    const std::string& getNome() const;
    void adicionarDisciplina(Disciplina* disciplina);
    // Método para listar as disciplinas do aluno
    void listarDisciplinas() const;
private:
    std::string nome;
    std::vector<Disciplina*> disciplinas;
};

#endif