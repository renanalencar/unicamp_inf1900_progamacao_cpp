#ifndef ITEM_H
#define ITEM_H
 
class Item {
private:
	int codigo;
    int quantidade;
    float precoUnitario;
  
public: 
    Item(int cod,int quant,float preco);
    void imprime();
    float custoTotal();
};

#endif