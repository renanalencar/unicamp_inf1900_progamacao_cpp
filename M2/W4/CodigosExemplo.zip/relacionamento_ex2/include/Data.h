#ifndef DATA_H
#define DATA_H

#include <iostream>

class Data {
private:
   int dia,mes;
   int ano;  
public:
	Data(int d,int m,int a);
	void imprime();
};

#endif
