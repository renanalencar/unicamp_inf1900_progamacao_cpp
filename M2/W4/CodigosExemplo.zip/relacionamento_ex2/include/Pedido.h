#ifndef PEDIDO_H
#define PEDIDO_H

#include <iostream>
#include <vector>
#include "Item.h"
#include "Data.h"

class Pedido {
private:
	int numero;
    int vendedor;
    Data *dia;
    std::vector <Item *> lista;  
public:
    Pedido(int n,int v,Data *d);
    void adicionaItem(int cod,int quant,float preco);
    float calculaTotal();
    void imprime();
};

#endif