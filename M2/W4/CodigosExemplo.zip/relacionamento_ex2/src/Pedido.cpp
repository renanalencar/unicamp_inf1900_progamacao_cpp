#include "Pedido.h"

Pedido::Pedido(int n,int v,Data *d):numero(n),vendedor(v),dia(d) {}

void Pedido::adicionaItem(int cod,int quant,float preco) {
    lista.push_back(new Item(cod,quant,preco));  
}

float Pedido::calculaTotal() {
    float total = 0;
    for(int qual=0;qual<lista.size();qual++) {
      Item *umItem = lista.at(qual);
      total = total + umItem->custoTotal();
    }
    return total;  
}
 
void Pedido::imprime() {
    std::cout<< "Pedido #" << numero << " do vendedor " << vendedor << std::endl;
    dia->imprime();
    std::cout<<  "Itens:" << std::endl;
    for(int qual=0;qual<lista.size();qual++) {
		Item *umItem = lista.at(qual);
		std::cout<<  " * ";
		umItem->imprime();
    }
    std::cout << "Total do pedido: " << calculaTotal() << std::endl;
 }
