#include "Data.h"

Data::Data(int d,int m,int a) {  
   dia = d;  mes = m; ano = a;  
}
    
void Data::imprime() {
    std::cout << "Data: " << dia<< "/" << mes << "/" << ano << std::endl;    
}

