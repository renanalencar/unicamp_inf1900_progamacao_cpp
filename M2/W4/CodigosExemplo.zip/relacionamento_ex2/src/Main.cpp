#include <iostream>
#include "Data.h"
#include "Item.h"
#include "Pedido.h"

 int main()
 {
	 Data *hoje = new Data(19, 8, 2023);
	 Pedido *p = new Pedido(1,3,hoje);

     p->adicionaItem(1215,10, 9.45);
     p->adicionaItem(1217, 1,21.00);
     p->adicionaItem(1223, 1,22.05);
     p->adicionaItem(1249, 3,50.95);
      
     p->imprime();  
	 return 0;
 }

  
