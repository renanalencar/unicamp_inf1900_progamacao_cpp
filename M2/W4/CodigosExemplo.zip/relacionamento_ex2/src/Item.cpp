#include "Item.h"
#include <iostream>

Item::Item(int cod,int quant,float preco) {
    codigo = cod; quantidade = quant; precoUnitario = preco;
}

void Item::imprime() {
    std::cout << "Item: codigo " << codigo << " " <<
                       quantidade << " unidades a " <<
                       precoUnitario << " cada." << std::endl;    
}

float Item::custoTotal() {
    return quantidade*precoUnitario;      
}
