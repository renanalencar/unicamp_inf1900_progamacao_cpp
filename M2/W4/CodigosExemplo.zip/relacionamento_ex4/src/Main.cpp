#include <iostream>
#include "Caixa.h"
#include "Produto.h"
#include "Venda.h"
#include "VendaVista.h"
#include "VendaPrazo.h"

 int main()
 {
     Venda *venda1,*venda2,*venda3;
	 venda1 = new Venda();
	 venda1->adicionarProduto(Produto(1215, 10, 9.50));

     venda2 = new VendaVista(15);
	 venda2->adicionarProduto(Produto(1217, 1, 21.00));
	 venda2->adicionarProduto(Produto(1218, 2, 24.00));

     venda3 = new VendaPrazo(10.0); // 10% de juros
	 venda3->adicionarProduto(Produto(1223, 1, 22.00));
	 venda3->adicionarProduto(Produto(1249, 3, 50.00));

     Caixa caixa;
     caixa.adicionarVenda(venda1);
     caixa.adicionarVenda(venda2);
     caixa.adicionarVenda(venda3);

     double totalVendas = caixa.calcularTotalVendas();

     std::cout << "Total de vendas no caixa: R$" << totalVendas << std::endl;

	 return 0;
 }

  
