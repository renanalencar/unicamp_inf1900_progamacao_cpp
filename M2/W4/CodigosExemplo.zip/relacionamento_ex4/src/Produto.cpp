#include "Produto.h"
#include <iostream>

Produto::Produto(int codigo, int quantidade, double preco) : codigo(codigo), quantidade(quantidade), preco(preco) {}

double Produto::getTotal() const {
    return quantidade * preco;
}

