#include "VendaVista.h"

VendaVista::VendaVista(double d): Venda() {
	desconto=d;
}

double VendaVista::getTotal() const {
    return Venda::getTotal()-desconto;
}

void VendaVista::imprime() const {
	std::cout << "Venda a vista realizada no valor de: " << Venda::getTotal() << " com desconto de " << desconto << " totalizando " << getTotal() <<std::endl;
}
