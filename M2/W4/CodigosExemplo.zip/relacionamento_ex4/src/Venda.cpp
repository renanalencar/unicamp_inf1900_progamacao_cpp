#include "Venda.h"

Venda::Venda() {
	valorTotal=0.0;
}

double Venda::getTotal() const {
    return valorTotal; 
}
// Método para adicionar um produto à venda
void Venda::adicionarProduto(const Produto& produto) {
    produtos.push_back(produto);
    valorTotal += produto.getTotal();
}

void Venda::imprime() const {
	std::cout << "Venda realizada no valor de: " << getTotal() << std::endl;
}
