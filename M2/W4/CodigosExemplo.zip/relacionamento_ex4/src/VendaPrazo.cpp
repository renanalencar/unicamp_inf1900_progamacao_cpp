#include "VendaPrazo.h"

VendaPrazo::VendaPrazo(double j): Venda(), juros(j){};

double VendaPrazo::getTotal() const {
    return Venda::getTotal()*(1.0+(juros/100));
}

void VendaPrazo::imprime() const {
	std::cout << "Venda a prazo realizada no valor de: " << Venda::getTotal() << " com juros de " << juros << " totalizando " << getTotal() << std::endl;
}
