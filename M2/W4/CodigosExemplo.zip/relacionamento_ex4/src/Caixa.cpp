#include "Caixa.h"

void Caixa::adicionarVenda(Venda* venda) {
    vendas.push_back(venda);
}

double Caixa::calcularTotalVendas() const {
    double total = 0.0;
    for (const Venda* venda : vendas) {
        total += venda->getTotal(); // Chama o getTotal da classe correspondente (polimorfismo)
		venda->imprime();
    }
    return total;
}
