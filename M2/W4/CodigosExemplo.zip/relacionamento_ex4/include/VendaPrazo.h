#ifndef VENDA_PRAZO_H
#define VENDA_PRAZO_H

#include <iostream>
#include <vector>
#include "Venda.h"

class VendaPrazo: public Venda {
private:
	double juros;
public:
	VendaPrazo(double);
	double getTotal() const override;
	void imprime() const override;
};


#endif