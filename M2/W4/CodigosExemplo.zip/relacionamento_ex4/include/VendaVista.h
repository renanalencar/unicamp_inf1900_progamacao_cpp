#ifndef VENDA_VISTA_H
#define VENDA_VISTA_H

#include <iostream>
#include <vector>
#include "Venda.h"

class VendaVista: public Venda {
private:
   double desconto;
public:
   VendaVista(double);
   double getTotal() const override;
   void imprime() const override;   
};

#endif

