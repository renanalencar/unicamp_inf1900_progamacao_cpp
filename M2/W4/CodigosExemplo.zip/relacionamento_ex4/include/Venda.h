#ifndef VENDA_H
#define VENDA_H

#include <iostream>
#include <vector>
#include "Produto.h"
#include "Data.h"

class Venda {
public:
	Venda();
    // Método virtual puro para calcular o total
    virtual double getTotal() const;
	void adicionarProduto(const Produto& produto);
	virtual void imprime() const;
protected:
    double valorTotal;
    std::vector<Produto> produtos;
};

#endif