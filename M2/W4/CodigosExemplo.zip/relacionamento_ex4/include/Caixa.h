#ifndef CAIXA_H
#define CAIXA_H

#include <iostream>
#include <vector>
#include "Venda.h"

class Caixa {
private:
    std::vector<Venda*> vendas;
public:
	void adicionarVenda(Venda* venda);
	double calcularTotalVendas() const;
};

#endif