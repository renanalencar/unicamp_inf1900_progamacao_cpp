#ifndef PRODUTO_H
#define PRODUTO_H
 
// Classe para representar um produto
class Produto {
public:
	Produto(int codigo, int quantidade, double preco);
	double getTotal() const;

private:
    int codigo;
    int quantidade;
    double preco;
};

#endif