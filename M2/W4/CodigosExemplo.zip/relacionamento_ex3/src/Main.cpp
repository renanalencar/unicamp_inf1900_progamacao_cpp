#include <iostream>
#include "Data.h"
#include "Evento.h"

int main() {
	Evento *encontro = new Evento("Encontro de Pessoas que Realmente Amam Programar",   new Data(1, 4, 2010));
    encontro->marcaDiaAdicional(new Data(2, 4, 2023));  
    encontro->marcaDiaAdicional(new Data(3, 4, 2023));  
    encontro->marcaDiaAdicional(new Data(4, 4, 2023));  
    encontro->imprime();    
}

  
