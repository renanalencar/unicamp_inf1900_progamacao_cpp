#include "Evento.h"

Evento::Evento(std::string n,Data *umDia) {
    nome = n;
    dia.push_back(umDia);
} 

void Evento::marcaDiaAdicional(Data *d) {
    dia.push_back(d);  
}

void Evento::imprime() {
    std::cout << "Evento: "  << nome << " ocorrerá nos dias:" << std::endl;
    for (int d = 0; d < dia.size(); d++) {
      std::cout << "  * ";
      Data *umaData = dia.at(d);
      umaData->imprime();
    }  
}

