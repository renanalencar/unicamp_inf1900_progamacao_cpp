#ifndef EVENTO_H
#define EVENTO_H

#include <iostream>
#include <vector>
#include "Data.h"

class Evento {
private:
   std::string nome;
   std::vector <Data *> dia;
public:
   Evento(std::string n,Data *umDia);
   void marcaDiaAdicional(Data *d);
   void imprime();
};

#endif

